import java.awt.Point;


public class Cell {
int value=0;;
Point point;
boolean full=false;;
}
