//by : Ahmed Akram
//last updated: 17/5/2018


import java.awt.Point;
import java.util.Scanner;


public class Square {
	int n;
	Cell [][] square;
	int currentValue=1;
	Cell currentCell;

	public Square(int n){
		this.n=n;
		this.square= new Cell [n][n];
		initializeSquare();	
	}

	//initialize the square with Cells and handling the first value of 1.
	public void initializeSquare(){
		for (int i =0 ; i < n ; i++){
			for(int j =0 ;j <n ; j++){
				square[i][j]=new Cell();
				square[i][j].point=new Point(i,j);
			}
		}

		this.currentCell=square[0][(n/2)];
		square[0][(n/2)].full=true;
		square[0][(n/2)].value=1;
		currentValue++;
	}

	//the next upright move the pointer will take to complete the magic square
	public void NextMove(){
		int i = currentCell.point.x;
		int j = currentCell.point.y;

		i--;
		j++;


		if(i<0 && j<n){
			i=n-1;
			this.currentCell=square[i][j];
			square[i][j].full=true;
			square[i][j].value=currentValue;
			currentValue++;
		}
		else if(i<0 && j==n){
			i=i+2;
			j--;
			this.currentCell=square[i][j];
			square[i][j].full=true;
			square[i][j].value=currentValue;
			currentValue++;
		}
		else if(i>=0 && j==n){
			j=0;
			this.currentCell=square[i][j];
			square[i][j].full=true;
			square[i][j].value=currentValue;
			currentValue++;
		}
		else if(i>=0 && j<n){
			if(square[i][j].full==true){
				i=i+2;
				j--;
				this.currentCell=square[i][j];
				square[i][j].full=true;
				square[i][j].value=currentValue;
				currentValue++;
			}else{
				this.currentCell=square[i][j];
				square[i][j].full=true;
				square[i][j].value=currentValue;
				currentValue++;
			}
		}


	}

	public void createMagicSquare(){
		while(currentValue <= (n*n)){
			NextMove();
		}
	}

	public void print(){
		for (int i =0 ; i < n ; i++ ){
			for(int j =0 ;j <n ; j++){
				System.out.print(square[i][j].value + "|" + " ");
			}
			System.out.println();
		}

	}

	//to verify whether this is a valid magic square or not
	public void Verify(){				
		int [] sum = new int [n];
		boolean verified=true;

		for (int i =0 ; i < n ; i++ ){
			sum[i]=0;
			for(int j =0 ;j <n ; j++){
				sum[i] = sum[i] +  square[i][j].value;
			}
			System.out.println(("sum of the"+ " " + i + " " + "row:" + " " + sum[i] ));
			System.out.println(("sum of the"+ " " + i + " " + "column:" + " " + sum[i] ));

		}

		for(int k =0 ; k< sum.length-1 ; k++){
			if(sum[k] != sum[k+1])
				verified=false;	
		}
		if(!verified)
			System.out.println("this is not a true magical square !");
		else
			System.out.println("It's a valid magic square, the sum of all rows and columns is equal !");
	}

	public static void main (String[] args){

		int n =0;

		//Making sure that the entered number is odd

		while(n%2==0){
			System.out.println("please enter an odd number");
			Scanner sc = new Scanner(System.in);
			n = sc.nextInt();
		}


		System.out.println("here is the Square:");
		Square x = new Square(n);	
		x.createMagicSquare();
		x.print();
		x.Verify();
	}

}
